# Contacts_App
Contacts_App provides a feastur for the user to Add Contacts to the Server by authenticating user's identity using "Sign In" and "Sign Up" forms
Open VS Code 
open the project folder
#Run Django Server 
      python manage.py runserver

On the the server url: https:\\127.0.0.1:8000  the output will be seen