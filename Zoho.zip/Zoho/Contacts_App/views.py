from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_exempt

# Create your views here.
def home(HttpRequest):
    return render(HttpRequest,'SignIn.html'),
@csrf_exempt
def signin(request):
    mail=request.POST['email']
    passw=request.POST['psw']

    return render(request,)
@csrf_exempt
def signup(request):
    smail=request.POST['e-mail']
    spassw=request.POST['pasw']
    sec=request.POST['secrt']